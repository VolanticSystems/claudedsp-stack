#!/bin/bash
# ClaudeDSP - Claude launcher with session management (Linux)
#
# Install:
#   cp claudedsp-linux.sh /usr/local/bin/claudedsp
#   chmod +x /usr/local/bin/claudedsp
#
# Usage:
#   claudedsp                       Launch Claude normally
#   claudedsp l                     List saved sessions
#   claudedsp 3                     Resume session #3
#   claudedsp --proj /path/to/dir   Launch in a specific directory

DSP_DIR="$HOME/.claudedsp"
SESSIONS_FILE="$DSP_DIR/sessions.txt"
NOTES_DIR="$DSP_DIR/notes"
CLAUDE_EXE=$(command -v claude || echo "$HOME/.local/bin/claude")
EDITOR="${EDITOR:-nano}"

mkdir -p "$DSP_DIR" "$NOTES_DIR"
touch "$SESSIONS_FILE"

# ---- Functions ----

show_list() {
    local count
    count=$(grep -c '.' "$SESSIONS_FILE" 2>/dev/null || echo 0)
    if [[ $count -eq 0 ]]; then
        echo ""
        echo "  No saved sessions."
        echo ""
        return 1
    fi
    echo ""
    echo "  === Saved Sessions ==="
    echo ""
    IDX=0
    while IFS='|' read -r guid dir desc; do
        ((IDX++))
        echo "  $IDX. $desc"
    done < "$SESSIONS_FILE"
    echo ""
    echo "  E. Edit this list"
    return 0
}

get_entry() {
    local pick=$1 idx=0
    while IFS='|' read -r guid dir desc; do
        ((idx++))
        if [[ $idx -eq $pick ]]; then
            SEL_GUID="$guid"
            SEL_DIR="$dir"
            SEL_DESC="$desc"
            return 0
        fi
    done < "$SESSIONS_FILE"
    return 1
}

find_session_guid() {
    SESSION_GUID=""
    local proj_key
    proj_key=$(pwd | sed 's|/|-|g; s|^-||')
    local claude_proj_dir="$HOME/.claude/projects/$proj_key"
    [[ -d "$claude_proj_dir" ]] || return 1
    local newest
    newest=$(ls -t "$claude_proj_dir"/*.jsonl 2>/dev/null | head -1)
    [[ -n "$newest" ]] && SESSION_GUID=$(basename "$newest" .jsonl)
}

move_to_top() {
    local tmp="$SESSIONS_FILE.tmp"
    grep "^$SESSION_GUID|" "$SESSIONS_FILE" > "$tmp"
    grep -v "^$SESSION_GUID|" "$SESSIONS_FILE" >> "$tmp"
    mv "$tmp" "$SESSIONS_FILE"
}

update_desc() {
    local new_desc="$1" tmp="$SESSIONS_FILE.tmp"
    while IFS='|' read -r guid dir desc; do
        if [[ "$guid" == "$SESSION_GUID" ]]; then
            echo "$guid|$dir|$new_desc"
        else
            echo "$guid|$dir|$desc"
        fi
    done < "$SESSIONS_FILE" > "$tmp"
    mv "$tmp" "$SESSIONS_FILE"
}

post_exit() {
    find_session_guid || return
    [[ -z "$SESSION_GUID" ]] && return

    if grep -q "^$SESSION_GUID|" "$SESSIONS_FILE"; then
        move_to_top
        local cur_desc
        cur_desc=$(grep "^$SESSION_GUID|" "$SESSIONS_FILE" | head -1 | cut -d'|' -f3)
        echo ""
        echo "  Session: $cur_desc"
        read -rp "  Rename? (Enter to keep): " new_desc
        [[ -n "$new_desc" ]] && update_desc "$new_desc"
    else
        echo ""
        read -rp "  Describe this session (Enter to skip): " session_desc
        [[ -z "$session_desc" ]] && return
        local tmp="$SESSIONS_FILE.tmp"
        echo "$SESSION_GUID|$(pwd)|$session_desc" > "$tmp"
        cat "$SESSIONS_FILE" >> "$tmp"
        mv "$tmp" "$SESSIONS_FILE"
    fi

    echo ""
    read -rp "  Add/edit notes? [y/N]: " edit_notes
    if [[ "${edit_notes,,}" == "y" ]]; then
        $EDITOR "$NOTES_DIR/$SESSION_GUID.txt"
    fi
}

do_resume() {
    local pick=$1
    if ! [[ "$pick" =~ ^[0-9]+$ ]] || [[ $pick -lt 1 || $pick -gt $IDX ]]; then
        echo "  Invalid selection."
        return 1
    fi
    get_entry "$pick"

    echo ""
    local review="Y"
    read -rp "  Review notes? [Y/n]: " review
    if [[ "${review,,}" != "n" ]]; then
        echo ""
        echo "  --- Notes: $SEL_DESC ---"
        echo ""
        if [[ -f "$NOTES_DIR/$SEL_GUID.txt" ]]; then
            cat "$NOTES_DIR/$SEL_GUID.txt"
        else
            echo "  No notes yet."
        fi
        echo ""
        echo "  --- End of notes ---"
        echo ""
        read -rp "  Press Enter to continue..."
    fi

    if [[ ! -d "$SEL_DIR" ]]; then
        echo "  Error: Project directory not found: $SEL_DIR"
        return 1
    fi
    local orig_dir
    orig_dir=$(pwd)
    cd "$SEL_DIR" || return 1
    "$CLAUDE_EXE" --dangerously-skip-permissions --resume "$SEL_GUID"
    post_exit
    cd "$orig_dir" || true
}

# ---- Main ----

# List mode
if [[ "${1,,}" == "l" ]]; then
    while true; do
        show_list || exit 0
        echo ""
        read -rp "  Pick a session (Enter to quit): " pick
        [[ -z "$pick" ]] && exit 0
        if [[ "${pick,,}" == "e" ]]; then
            $EDITOR "$SESSIONS_FILE"
            continue
        fi
        do_resume "$pick"
        exit 0
    done
fi

# Direct resume by number
if [[ "$1" =~ ^[0-9]+$ ]]; then
    show_list || { echo "  No saved sessions."; exit 0; }
    do_resume "$1"
    exit 0
fi

# Normal mode
PROJ_DIR=""
ARGS=()
while [[ $# -gt 0 ]]; do
    case "$1" in
        --proj)
            PROJ_DIR="$2"
            shift 2
            ;;
        *)
            ARGS+=("$1")
            shift
            ;;
    esac
done

ORIG_DIR=$(pwd)
if [[ -n "$PROJ_DIR" ]]; then
    if [[ ! -d "$PROJ_DIR" ]]; then
        echo "Error: Directory not found: $PROJ_DIR"
        exit 1
    fi
    cd "$PROJ_DIR" || exit 1
fi

"$CLAUDE_EXE" --dangerously-skip-permissions "${ARGS[@]}"

post_exit

[[ -n "$PROJ_DIR" ]] && cd "$ORIG_DIR" 2>/dev/null
