# ClaudeDSP - Claude launcher with session management (PowerShell)
#
# Add this function to your $PROFILE:
#   notepad $PROFILE
#
# Usage:
#   claudedsp                       Launch Claude normally
#   claudedsp l                     List saved sessions
#   claudedsp 3                     Resume session #3
#   claudedsp --proj C:\myproject   Launch in a specific directory

function claudedsp {
    $dspDir = "$env:USERPROFILE\.claudedsp"
    $sessionsFile = "$dspDir\sessions.txt"
    $notesDir = "$dspDir\notes"
    $claudeExe = "$env:USERPROFILE\.local\bin\claude.exe"

    if (-not (Test-Path $dspDir)) { New-Item -ItemType Directory -Path $dspDir | Out-Null }
    if (-not (Test-Path $notesDir)) { New-Item -ItemType Directory -Path $notesDir | Out-Null }
    if (-not (Test-Path $sessionsFile)) { New-Item -ItemType File -Path $sessionsFile | Out-Null }

    function Get-Sessions {
        $lines = Get-Content $sessionsFile | Where-Object { $_.Trim() -ne '' }
        $sessions = @()
        foreach ($line in $lines) {
            $parts = $line -split '\|', 3
            $sessions += [PSCustomObject]@{ Guid=$parts[0]; Dir=$parts[1]; Desc=$parts[2] }
        }
        return $sessions
    }

    function Save-Sessions($sessions) {
        $lines = $sessions | ForEach-Object { "$($_.Guid)|$($_.Dir)|$($_.Desc)" }
        $lines | Set-Content $sessionsFile
    }

    function Show-List($sessions) {
        Write-Host ""
        Write-Host "  === Saved Sessions ==="
        Write-Host ""
        for ($i = 0; $i -lt $sessions.Count; $i++) {
            Write-Host "  $($i+1). $($sessions[$i].Desc)"
        }
        Write-Host ""
        Write-Host "  E. Edit this list"
    }

    function Do-PostExit {
        $projKey = (Get-Location).Path -replace ':', '-' -replace '\\', '-'
        $projDir = "$env:USERPROFILE\.claude\projects\$projKey"
        if (-not (Test-Path $projDir)) { return }
        $newest = Get-ChildItem "$projDir\*.jsonl" -ErrorAction SilentlyContinue |
            Sort-Object LastWriteTime -Descending | Select-Object -First 1
        if (-not $newest) { return }
        $guid = $newest.BaseName
        $sessions = Get-Sessions
        $existing = $sessions | Where-Object { $_.Guid -eq $guid }
        if ($existing) {
            $sessions = @($existing) + @($sessions | Where-Object { $_.Guid -ne $guid })
            Save-Sessions $sessions
            Write-Host ""
            Write-Host "  Session: $($existing.Desc)"
            $rename = Read-Host "  Rename? (Enter to keep)"
            if ($rename) {
                $existing.Desc = $rename
                Save-Sessions $sessions
            }
        } else {
            Write-Host ""
            $desc = Read-Host "  Describe this session (Enter to skip)"
            if (-not $desc) { return }
            $newEntry = [PSCustomObject]@{ Guid=$guid; Dir=(Get-Location).Path; Desc=$desc }
            $sessions = @($newEntry) + @($sessions)
            Save-Sessions $sessions
        }
        Write-Host ""
        $editNotes = Read-Host "  Add/edit notes? [y/N]"
        if ($editNotes -eq 'y') {
            notepad "$notesDir\$guid.txt"
        }
    }

    function Do-Resume($pick, $sessions) {
        if ($pick -lt 1 -or $pick -gt $sessions.Count) {
            Write-Host "  Invalid selection."
            return
        }
        $sel = $sessions[$pick - 1]
        Write-Host ""
        $review = Read-Host "  Review notes? [Y/n]"
        if ($review -ne 'n') {
            Write-Host ""
            Write-Host "  --- Notes: $($sel.Desc) ---"
            Write-Host ""
            $notesPath = "$notesDir\$($sel.Guid).txt"
            if (Test-Path $notesPath) {
                Get-Content $notesPath | Write-Host
            } else {
                Write-Host "  No notes yet."
            }
            Write-Host ""
            Write-Host "  --- End of notes ---"
            Write-Host ""
            Read-Host "  Press Enter to continue"
        }
        if (-not (Test-Path $sel.Dir)) {
            Write-Host "  Error: Project directory not found: $($sel.Dir)"
            return
        }
        $origDir = Get-Location
        Set-Location $sel.Dir
        & $claudeExe --dangerously-skip-permissions --resume $sel.Guid
        Do-PostExit
        Set-Location $origDir
    }

    # --- Main ---
    $firstArg = $args[0]

    # List mode
    if ($firstArg -eq 'l' -or $firstArg -eq 'L') {
        while ($true) {
            $sessions = Get-Sessions
            if ($sessions.Count -eq 0) {
                Write-Host ""
                Write-Host "  No saved sessions."
                Write-Host ""
                return
            }
            Show-List $sessions
            Write-Host ""
            $pick = Read-Host "  Pick a session (Enter to quit)"
            if (-not $pick) { return }
            if ($pick -eq 'e' -or $pick -eq 'E') {
                notepad $sessionsFile
                continue
            }
            if ($pick -match '^\d+$') {
                Do-Resume ([int]$pick) $sessions
                return
            }
            Write-Host "  Invalid selection."
        }
        return
    }

    # Direct resume by number
    if ($firstArg -match '^\d+$') {
        $sessions = Get-Sessions
        if ($sessions.Count -eq 0) {
            Write-Host "  No saved sessions."
            return
        }
        Show-List $sessions
        Do-Resume ([int]$firstArg) $sessions
        return
    }

    # Normal mode
    $projDir = $null
    $passArgs = @()
    $i = 0
    while ($i -lt $args.Count) {
        if ($args[$i] -eq '--proj' -and ($i + 1) -lt $args.Count) {
            $projDir = $args[$i + 1]
            $i += 2
        } else {
            $passArgs += $args[$i]
            $i++
        }
    }

    $origDir = Get-Location
    if ($projDir) {
        if (-not (Test-Path $projDir)) {
            Write-Host "Error: Directory not found: $projDir"
            return
        }
        Set-Location $projDir
    }

    if ($passArgs.Count -gt 0) {
        & $claudeExe --dangerously-skip-permissions @passArgs
    } else {
        & $claudeExe --dangerously-skip-permissions
    }

    Do-PostExit

    if ($projDir) { Set-Location $origDir }
}
